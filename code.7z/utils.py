
from pydub import AudioSegment
from pydub.playback import play

def play_mp3(fichier_mp3):
    audio = AudioSegment.from_mp3(fichier_mp3)
    play(audio)

