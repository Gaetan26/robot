
from utils import play_mp3

play_mp3('audio/welcome.mp3')