import cv2
import numpy as np
import mediapipe as mp
from scipy.fftpack import fft
from scipy.signal import butter, filtfilt
import time

def butter_lowpass_filter(data, cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    return filtfilt(b, a, data)

def mesurer_bpm(duree=20):
    cap = cv2.VideoCapture(0)
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(static_image_mode=False, max_num_hands=1)
    green_signals = []
    times = []
    bpm_history = []

    sampling_rate = 30
    live_window = 5
    bpm_min = 40
    bpm_max = 180
    valeur = "en attente..."

    print(f"[INFO] Démarrage de la capture vidéo pour {duree} s…")
    start_time = time.time()

    # Mode plein écran
    cv2.namedWindow('Frame', cv2.WND_PROP_FULLSCREEN)
    cv2.setWindowProperty('Frame', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = hands.process(rgb)

        if res.multi_hand_landmarks:
            h, w, _ = frame.shape
            lm = res.multi_hand_landmarks[0]
            xs = [p.x for p in lm.landmark]
            ys = [p.y for p in lm.landmark]
            x1 = max(int(min(xs)*w) - 5, 0)
            x2 = min(int(max(xs)*w) + 5, w)
            y1 = max(int(min(ys)*h) - 5, 0)
            y2 = min(int(max(ys)*h) + 5, h)

            roi = frame[y1:y2, x1:x2]
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0,255,0), 2)
            cv2.putText(frame, f"Collecte: {valeur}", (x1, y2 + 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

            if roi.size:
                t = time.time() - start_time
                green_signals.append(np.mean(roi[:,:,1]))
                times.append(t)

                mask = np.array(times) >= (t - live_window)
                rt = np.array(times)[mask]
                rs = np.array(green_signals)[mask]

                if len(rt) > 10:
                    et = np.linspace(rt.min(), rt.max(), len(rt))
                    es = np.interp(et, rt, rs)

                    if len(es) > 18:
                        fsig = butter_lowpass_filter(es, cutoff=2.5, fs=sampling_rate, order=5)
                    else:
                        fsig = es

                    N = len(fsig)
                    freqs = np.fft.fftfreq(N, d=1/sampling_rate)
                    fft_vals = np.abs(fft(fsig))
                    pf = freqs[freqs > 0]
                    pv = fft_vals[freqs > 0]
                    m = (pf >= 0.8) & (pf <= 3.0)
                    pf, pv = pf[m], pv[m]

                    if len(pv):
                        bpm = pf[np.argmax(pv)] * 60
                        if bpm_min <= bpm <= bpm_max:
                            valeur = int(bpm)
                            bpm_history.append(bpm)

        cv2.imshow('Frame', frame)

        if time.time() - start_time > duree:
            break
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    if bpm_history:
        avg_bpm = int(np.mean(bpm_history))
        print(f"[RESULTAT] BPM moyen sur {duree}s : {avg_bpm} BPM")
        return avg_bpm
    else:
        print("[RESULTAT] Aucune valeur de BPM valide collectée.")
        return None