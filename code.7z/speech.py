from vosk import Model, KaldiRecognizer
import pyaudio
import json
import time

def ecouter_micro(silence_max=12):
    model = Model("model")
    recognizer = KaldiRecognizer(model, 16000)

    audio = pyaudio.PyAudio()
    stream = audio.open(format=pyaudio.paInt16, channels=1, rate=16000,
                        input=True, frames_per_buffer=8000)
    stream.start_stream()

    print("Parlez dans le micro...")
    phrases = []
    dernier_son = time.time()

    try:
        while True:
            data = stream.read(4000, exception_on_overflow=False)
            if recognizer.AcceptWaveform(data):
                result = json.loads(recognizer.Result())
                texte = result.get("text", "")
                if texte:
                    print("→ Texte reconnu :", texte)
                    phrases.append(texte)
                    dernier_son = time.time()
            else:
                if time.time() - dernier_son > silence_max:
                    print(f"Aucun son détecté depuis {silence_max} secondes. Fin.")
                    break
    finally:
        stream.stop_stream()
        stream.close()
        audio.terminate()

    return phrases
