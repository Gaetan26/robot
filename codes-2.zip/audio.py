
from pydub import AudioSegment
import pyaudio
import threading

class AudioPlayer:
    def __init__(self):
        self.p = pyaudio.PyAudio()
        self.stream = None
        self.lock = threading.Lock()

    def _open_stream(self, sample_width, channels, frame_rate):
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
        self.stream = self.p.open(format=self.p.get_format_from_width(sample_width),
                                  channels=channels,
                                  rate=frame_rate,
                                  output=True)

    def play_mp3(self, mp3_path):
        sound = AudioSegment.from_mp3(mp3_path)
        
        with self.lock:
            self._open_stream(sound.sample_width, sound.channels, sound.frame_rate)

            chunk_size = 1024
            raw_data = sound.raw_data

            for i in range(0, len(raw_data), chunk_size):
                self.stream.write(raw_data[i:i+chunk_size])

    def close(self):
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
        self.p.terminate()
