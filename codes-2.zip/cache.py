
import customtkinter as ctk
import requests
from utils import play_mp3

# from facial import verifier_presence_personne
# from bpm import mesurer_bpm
from speech import ecouter_micro

import time
import threading


AI_AGENT_SERVICE = f"http://{input('ip:')}:8000/"

patient = {
    'lastname' : 'Suenge',
    'firstname' : 'Gaetan',
    'age' : 19,
    'gender' : 'male',
    'symptoms': """J'ai commencé par avoir de la fièvre, mais elle va et vient… comme des vagues. Une minute j'ai chaud, je transpire, et juste après j'ai des frissons, je grelotte comme si j'étais en plein hiver.
J'ai aussi des maux de tête très forts, comme si ma tête allait exploser. Et mes muscles, mes articulations… tout me fait mal, j'ai l'impression d'avoir la grippe, mais en pire.
J'ai un peu la nausée, je n'arrive pas à manger, et parfois j'ai mal au ventre. Je suis vraiment épuisé, j'ai du mal à rester debout, et mon cœur bat vite"""
}

def create_audio(text, output):
    
    data = {
        "text": text,
    }

    response = requests.post(TEXT_TO_SPEECH_SERVICE, json=data)

    if response.status_code == 200:
        with open(f"audio/{output}", "wb") as f:
            f.write(response.content)
        print(f"Fichier audio sauvegardé sous '{output}.mp3'")
    else:
        print("Erreur :", response.status_code)
        print("Réponse :", response.text)
    
    return 'audio/' + output


def create_questions():
    global questions, questions_audio
    
    questions_audio = []
    response = requests.post(AI_AGENT_SERVICE + 'quiz', json=patient)
    
    if response.status_code == 200:
        questions = response.json()
        for key in questions.keys():
            for i in range(len(questions[key])):
                questions_audio.append(create_audio(questions[key][i], f'{key}-{i}.mp3'))


welcome = create_audio("Bonjour Monsieur Wilson", "welcome.mp3")
instruction0 = create_audio("Nous allons vous identifier", "instruction0.mp3")
instruction1 = create_audio("Veuillez placer votre visage devant la camera", "instruction1.mp3")
instruction2 = create_audio("Veuillez placer votre main devant la camera", "instruction2.mp3")
instruction3 = create_audio("Nous allons vous posez quelques questions", "instruction3.mp3")


questions, questions_audio, answers = None, [], []
threading.Thread(target=create_questions).start()

play_mp3(instruction0)

time.sleep(1.5)
play_mp3(instruction1)

if verifier_presence_personne('Wilson', 'faces/input.jpg', 20):
    time.sleep(1.5)
    play_mp3(welcome)
    
    play_mp3(instruction2)
    bpm = mesurer_bpm(15)

    time.sleep(1.5)
    play_mp3(instruction3)

    time.sleep(1.5)

    while questions_audio is None:
        pass
    
    while len(questions_audio) < 6:
        pass

    for question in questions_audio:
        play_mp3(question)
        answer = ecouter_micro()
        answer_str = ""
        for char in answer:
            answer_str += char + " "
        answers.append(answer_str)

