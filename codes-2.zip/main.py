
import speech_totext, audio, requests, time
from text_tospeech import create_audio
from threading import Thread


AI_AGENT_SERVICE = f"http://{input('ip:')}:8000/"


def ai_process_0():
    global ai_questions, ai_questions_speech, ai_process_0_done, ai_questions_

    response = requests.post(
        AI_AGENT_SERVICE + 'quiz',
        json=subject
    )

    if response.status_code == 200:
        ai_questions = response.json()
        for key in ai_questions.keys():
            for i in range(len(ai_questions[key])):
                ai_questions_speech.append(
                    create_audio(
                        ai_questions[key][i],
                        f'{key}-{i}'
                    )
                )

                ai_questions_.append(
                    ai_questions[key][i]
                )
    
    ai_process_0_done = True
    return True


def ai_process_1():
    response = requests.post(
        AI_AGENT_SERVICE + 'report',
        json={
            'questions': ai_questions_,
            'answers': answers
        }
    )

    if response.status_code == 200:
        report = response.json()
        print(report)
    
    return True


audioplayer = audio.AudioPlayer()
speech_tt = speech_totext.SpeechTT('model')


subject = {
    'lastname':'suenge',
    'firstname':'gaetan',
    'age':19,
    'gender':'male',
    'symptoms':"""J'ai commencé par avoir de la fièvre, mais elle va et vient… comme des vagues. Une minute j'ai chaud, je transpire, et juste après j'ai des frissons, je grelotte comme si j'étais en plein hiver.
J'ai aussi des maux de tête très forts, comme si ma tête allait exploser. Et mes muscles, mes articulations… tout me fait mal, j'ai l'impression d'avoir la grippe, mais en pire.
J'ai un peu la nausée, je n'arrive pas à manger, et parfois j'ai mal au ventre. Je suis vraiment épuisé, j'ai du mal à rester debout, et mon cœur bat vite"""
}

Thread(target=ai_process_0).start()

ai_questions = []
ai_questions_ = []
ai_questions_speech = []

ai_process_0_done = False

answers = []

i0 = create_audio("Bonjour monsieur ou madame, nous allons commencer par vous identifier", "i0")
i1 = create_audio("Veuillez s'il-vous-plait placer votre visage devant la camera", "i1")
i2 = create_audio("Veuillez placer votre main devant la camera", 'i2')
i3 = create_audio(f"Bonjour {subject['firstname']}, content de te revoir!", 'i3')
i4 = create_audio("Nous allons discuter un peu pour evaluer ton etat.", 'i4')
i5 = create_audio(
    """Voilà comment nous allons procéder : je vais te poser une série de questions, puis les analyser, en poser d'autres, et enfin tu pourras toi aussi me poser des questions""", 'i5')
i6 = create_audio("Laisse-moi finir de mettre au point mes questions.", 'i6')
i7 = create_audio("C'est bon, nous sommes prêts à démarrer !", 'i7')
i8 = create_audio("Je n'ai plus aucune question, qu'a tu d'autres a me dire ?", 'i8')
i9 = create_audio(f"Merci {subject['firstname']}, je vais tout transmettre au Medecin, passe une bonne journee !", 'i9')

for sound in [i0, i1, i2, i3, i4, i5]:
    audioplayer.play_mp3(sound)

bpm = 56

time.sleep(2)
if not ai_process_0_done:
    audioplayer.play_mp3(i6)
    time.sleep(0.5)

while not ai_process_0_done:
    pass

ai_questions_speech.append(i8)
audioplayer.play_mp3(i7)

for question in ai_questions_speech:
    audioplayer.play_mp3(question)
    
    answer = speech_tt.listen()
    answers.append(answer)
    
    time.sleep(0.5)


ai_questions_.append("Ton rythme cardiaque")
answers.append(f"{bpm} bpm")

audioplayer.play_mp3(i9)
ai_process_1()