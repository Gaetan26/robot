
from gtts import gTTS


output_dir = 'audio/'
def create_audio(text, output):
    try:
        tts = gTTS(text=text, lang='fr')
        tts.save(output_dir + output + '.mp3')
        return output_dir + output + '.mp3'
    except Exception as e:
        return None