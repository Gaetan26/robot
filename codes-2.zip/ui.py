
import flet as ft
from threading import Thread


def back():
    
    import speech_totext, audio, requests, time
    from text_tospeech import create_audio


    global sentence, sentence_box, bot, coffee, files, markdown, markdown_box


    AI_AGENT_SERVICE = f"http://{input('ip:')}:8000/"

    def ai_process_0():
        global ai_questions, ai_questions_speech, ai_process_0_done, ai_questions_

        response = requests.post(
            AI_AGENT_SERVICE + 'quiz',
            json=subject
        )

        if response.status_code == 200:
            ai_questions = response.json()
            for key in ai_questions.keys():
                for i in range(len(ai_questions[key])):
                    ai_questions_speech.append(
                        create_audio(
                            ai_questions[key][i],
                            f'{key}-{i}'
                        )
                    )

                    ai_questions_.append(
                        ai_questions[key][i]
                    )
        
        ai_process_0_done = True
        return True


    def ai_process_1():
        global report

        response = requests.post(
            AI_AGENT_SERVICE + 'report',
            json={
                'questions': ai_questions_,
                'answers': answers
            }
        )

        if response.status_code == 200:
            report = response.json()
        
        return True


    audioplayer = audio.AudioPlayer()
    speech_tt = speech_totext.SpeechTT('model')


    subject = {
        'lastname':'suenge',
        'firstname':'gaetan',
        'age':19,
        'gender':'male',
        'symptoms':"""J'ai commencé par avoir de la fièvre, mais elle va et vient… comme des vagues. Une minute j'ai chaud, je transpire, et juste après j'ai des frissons, je grelotte comme si j'étais en plein hiver.
    J'ai aussi des maux de tête très forts, comme si ma tête allait exploser. Et mes muscles, mes articulations… tout me fait mal, j'ai l'impression d'avoir la grippe, mais en pire.
    J'ai un peu la nausée, je n'arrive pas à manger, et parfois j'ai mal au ventre. Je suis vraiment épuisé, j'ai du mal à rester debout, et mon cœur bat vite"""
    }

    Thread(target=ai_process_0).start()

    change_visible_object(files)

    i0 = create_audio("Bonjour monsieur ou madame, nous allons commencer par vous identifier", "i0")
    i1 = create_audio("Veuillez s'il-vous-plait placer votre visage devant la camera", "i1")
    i2 = create_audio("Veuillez placer votre main devant la camera", 'i2')
    i3 = create_audio(f"Bonjour {subject['firstname']}, content de te revoir!", 'i3')
    i4 = create_audio("Nous allons discuter un peu pour evaluer ton etat.", 'i4')
    i5 = create_audio(
        """Voilà comment nous allons procéder : je vais te poser une série de questions, puis les analyser, en poser d'autres, et enfin tu pourras toi aussi me poser des questions""", 'i5')
    i6 = create_audio("Laisse-moi finir de mettre au point mes questions.", 'i6')
    i7 = create_audio("C'est bon, nous sommes prêts à démarrer !", 'i7')
    i8 = create_audio("Je n'ai plus aucune question, qu'a tu d'autres a me dire ?", 'i8')
    i9 = create_audio(f"Merci {subject['firstname']}, je vais tout transmettre au Medecin, passe une bonne journee !", 'i9')

    change_visible_object(bot)
    for sound in [i0, i1, i2, i3, i4, i5]:
        audioplayer.play_mp3(sound)

    bpm = 56

    time.sleep(2)
    if not ai_process_0_done:
        audioplayer.play_mp3(i6)
        time.sleep(0.5)

    change_visible_object(coffee)
    while not ai_process_0_done:
        pass

    change_visible_object(bot)
    ai_questions_speech.append(i8)
    ai_questions_.append("Je n'ai plus aucune question, qu'a tu d'autres a me dire ?")
    audioplayer.play_mp3(i7)

    for question_index in range(len(ai_questions_speech)):
        sentence.value = ai_questions_[question_index]
        change_visible_object(sentence_box)

        audioplayer.play_mp3(ai_questions_speech[question_index])
        
        answer = speech_tt.listen()
        answers.append(answer)
        
        time.sleep(0.5)

    change_visible_object(bot)

    ai_questions_.append("Ton rythme cardiaque")
    answers.append(f"{bpm} bpm")

    audioplayer.play_mp3(i9)

    change_visible_object(files)
    ai_process_1()

    page_.scroll = ft.ScrollMode.AUTO
    markdown.value = report
    change_visible_object(markdown_box)
    # page_.close()


def change_visible_object(target): 
    for o in [
        sentence_box,
        bot, coffee, files
    ]:
        o.visible = False
    
    target.visible = True
    page_.update()

def main(page: ft.Page):

    global page_
    
    page.fonts = {
        "montserrat" : 'https://gaetan26.github.io/robot/Montserrat.ttf'
    }

    page.title = "ANI User Interface"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.padding = ft.padding.all(50)
    
    page_ = page
    page.add(
        ft.Column(
            [  bot, coffee, files, sentence_box, markdown_box ],
            alignment=ft.MainAxisAlignment.CENTER,
            expand=True,
        )
    )

    Thread(target=back).start()


# GLOBALS
ai_questions = []
ai_questions_ = []
ai_questions_speech = []
ai_process_0_done = False
answers = []

report = ""


# Part 2
page_ = None

sentence = ft.Text(
    theme_style=ft.TextThemeStyle.HEADLINE_LARGE,
    font_family="montserrat",
    size=150,
    text_align=ft.TextAlign.CENTER,
)

sentence_box = ft.Container(
    content=sentence,
    alignment=ft.alignment.center,
    expand=True,
    visible=False
)

markdown = ft.Markdown(
    selectable=True,
    extension_set=ft.MarkdownExtensionSet.GITHUB_WEB,
)

markdown_box = ft.Container(
    content=ft.Column(
        [markdown]
    ),
    alignment=ft.alignment.center,
    expand=True,
    visible=False
)

bot = ft.Container(
    content=ft.Lottie(
        src="https://gaetan26.github.io/robot/Animation - 1746147682291.json",
        animate=True,
    ),
    alignment=ft.alignment.center,
    expand=True,
    visible=False
)

coffee = ft.Container(
    content=ft.Lottie(
        src="https://gaetan26.github.io/robot/Animation - 1746147912801.json",
        animate=True,
    ),
    alignment=ft.alignment.center,
    expand=True,
    visible=False
)

files = ft.Container(
    content=ft.Lottie(
        src="https://gaetan26.github.io/robot/Animation - 1746149963218.json",
        animate=True,
    ),
    alignment=ft.alignment.center,
    expand=True,
    visible=False
)

ft.app(main)