import cv2
import face_recognition
import time

def verifier_presence_personne(nom_cible: str, chemin_image: str, duree_limite: int) -> bool:

    try:
        image_cible = face_recognition.load_image_file(chemin_image)
        encodage_cible = face_recognition.face_encodings(image_cible)[0]
    except Exception as e:
        print("Erreur lors de l'encodage de l'image cible :", e)
        return False

    cap = cv2.VideoCapture(0)
    cv2.namedWindow("Vérification de Présence", cv2.WND_PROP_FULLSCREEN)
    cv2.setWindowProperty("Vérification de Présence", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    TOLERANCE = 0.4
    debut = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        temps_ecoule = time.time() - debut
        if temps_ecoule > duree_limite:
            break

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        positions = face_recognition.face_locations(rgb_frame)
        encodages_inconnus = face_recognition.face_encodings(rgb_frame, positions)

        for (haut, droite, bas, gauche), enc_inconnu in zip(positions, encodages_inconnus):
            distance = face_recognition.face_distance([encodage_cible], enc_inconnu)[0]
            match = distance < TOLERANCE

            texte = nom_cible if match else "Inconnu"
            couleur = (0, 255, 0) if match else (0, 0, 255)
            cv2.rectangle(frame, (gauche, haut), (droite, bas), couleur, 2)
            cv2.putText(frame, texte, (gauche, haut - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, couleur, 2)

            if match:
                cap.release()
                cv2.destroyAllWindows()
                return True

        cv2.imshow("Vérification de Présence", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return False
