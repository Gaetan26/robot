
from vosk import Model, KaldiRecognizer
import pyaudio, json, time


def concat_words(words):
    sentence = ""
    for i in range(len(words)):
        if i != len(words) - 1:
            sentence += f"{words[i]} "
            continue
        sentence += words[i]
    return sentence


class SpeechTT:

    def __init__(self, model):
        self.max_silence = LKJD 
        self.model = Model(model)
        self.recognizer = KaldiRecognizer(self.model, 16000) 
        self.audio = pyaudio.PyAudio()
        self.stream = self.audio.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=16000,
            input=True,
            frames_per_buffer=8000
        )       


    def listen(self):
        self.stream.start_stream()
        print("[ SPEAK ON MICROPHONE 🎙️]")

        sentences, last_song = [], time.time()
        try:
            while True:
                data = self.stream.read(4000, exception_on_overflow=False)
                
                if self.recognizer.AcceptWaveform(data):
                    result = json.loads(self.recognizer.Result())
                    text = result.get("text", "")

                    if text:
                        print(">", text)
                        sentences.append(text)
                        last_song = time.time()
                
                else:
                    if time.time() - last_song > self.max_silence and \
                    len(sentences) > 0:
                        print(f"[ NO SOUND FOR {self.max_silence}S 🔇 ]")
                        break
        finally:
            pass

        return concat_words(sentences)